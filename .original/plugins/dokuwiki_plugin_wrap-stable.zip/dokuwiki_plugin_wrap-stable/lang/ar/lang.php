<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author alhajr <alhajr300@gmail.com>
 */
$lang['column']                = 'عمود';
$lang['box']                   = 'مربع متوسط بسيط';
$lang['info']                  = 'مربع معلومات';
$lang['tip']                   = 'مربع تلميح';
$lang['important']             = 'مربع هام';
$lang['alert']                 = 'مربع التنبيه';
$lang['help']                  = 'مربع تعليمات';
$lang['download']              = 'مربع التحميل';
$lang['lo']                    = 'أقل أهمية';
