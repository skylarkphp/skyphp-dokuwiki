<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author alhajr <alhajr300@gmail.com>
 */
$lang['restrictedClasses']     = 'تقييد استخدام البرنامج المساعد لهذه الفئات (مفصولة بفاصلة)';
$lang['restrictionType']       = 'تعين نوع القيد، إذا كانت الفئات المذكورة أعلاه يجب تضمينها أو استبعادها';
$lang['restrictionType_o_0']   = 'السماح لجميع الفئات باستثناء تلك المذكورة أعلاه';
$lang['restrictionType_o_1']   = 'تقييد للفئات المذكورة أعلاه فقط وليس غيرها';
