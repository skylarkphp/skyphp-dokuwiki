<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Neli Dimitrova <neli.dimitrova.office@gmail.com>
 */
$lang['picker']                = 'Wrap приставка';
$lang['column']                = 'колони';
$lang['box']                   = 'обикновено центрирано поле';
$lang['info']                  = 'информационно поле';
$lang['tip']                   = 'поле за съвет';
$lang['important']             = 'поле за важно съобщение';
$lang['alert']                 = 'поле за предупреждение';
$lang['help']                  = 'поле за съобщение за помощ';
$lang['download']              = 'поле за сваляне';
$lang['todo']                  = 'поле за подсещане';
$lang['clear']                 = 'премахване на параметъра float';
$lang['em']                    = 'специално подчертано';
$lang['hi']                    = 'акцентирано';
$lang['lo']                    = 'маловажно';
