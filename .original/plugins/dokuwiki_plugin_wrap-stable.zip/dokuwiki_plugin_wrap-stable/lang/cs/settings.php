<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Jaroslav Lichtblau <jlichtblau@seznam.cz>
 */
$lang['noPrefix']              = 'Která (čárkou oddělená) jména tříd nemají být označována předponou "wrap_"?';
$lang['restrictedClasses']     = 'omezit použití zásuvného modulu na tyto (čárkou oddělené) třídy';
$lang['restrictionType']       = 'typ omezení, rozhoduje jestli mají být výše uvedené třídy zahrnuty nebo vyřazeny';
$lang['restrictionType_o_0']   = 'povolit všechny třídy kromě těch výše';
$lang['restrictionType_o_1']   = 'omezit pouze na třídy výše a žádné jiné';
$lang['syntaxDiv']             = 'Jaká syntax má být použita ve výběru pro zarovnání bloku? ';
$lang['syntaxSpan']            = 'Jaká syntax má být použita ve výběru pro zarovnání v řádku? ';
$lang['darkTpl']               = 'Optimalizovat barvy pro tmavý vzhled?';
