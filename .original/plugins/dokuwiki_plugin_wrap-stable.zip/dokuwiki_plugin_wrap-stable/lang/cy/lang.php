<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Alan Davies <ben.brynsadler@gmail.com>
 * @author diafol <ben.brynsadler@gmail.com>
 */
$lang['picker']                = 'Ategyn Wrap';
$lang['column']                = 'colofnau';
$lang['box']                   = 'blwch syml wedi\'i ganoli';
$lang['info']                  = 'blwch gwyb.';
$lang['tip']                   = 'blwch awgrym';
$lang['important']             = 'blwch pwysig';
$lang['alert']                 = 'blwch rhybudd';
$lang['help']                  = 'blwch cyngor';
$lang['download']              = 'blwch lawrlwytho';
$lang['todo']                  = 'blwch i-wneud';
$lang['clear']                 = 'clirio \'floats\'';
$lang['em']                    = 'gyda phwyslais arbennig';
$lang['hi']                    = 'aroleuedig';
$lang['lo']                    = 'llai arwyddocaol';
