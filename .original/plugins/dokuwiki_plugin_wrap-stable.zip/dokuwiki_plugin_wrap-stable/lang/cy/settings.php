<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Alan Davies <ben.brynsadler@gmail.com>
 */
$lang['noPrefix']              = 'Pa enwau dosbarth (gwahanu gan goma) na ddylai derbyn y rhagddodiad "wrap_"?';
$lang['restrictedClasses']     = 'cyfyngu defnydd yr ategyn hwn i\'r dosbarthiadau (gwahanu gan goma) hyn';
$lang['restrictionType']       = 'math y cyfyngiad, yn dynodi os caiff y dosbarthiadau uchod eu cynnwys neu eu heithrio';
$lang['restrictionType_o_0']   = 'caniatáu pob dosbarth ond y rhai uchod';
$lang['restrictionType_o_1']   = 'cyfyngu i\'r dosbarthiadau uchod yn unig';
$lang['syntaxDiv']             = 'Pa gystrawen a ddylid defnyddio yn newisydd y bar offer ar gyfer wrapiau bloc?';
$lang['syntaxSpan']            = 'Pa gystrawen a ddylid defnyddio yn newisydd y bar offer ar gyfer wrapiau mewnlin?';
$lang['darkTpl']               = 'Optimeiddio lliwiau ar gyfer templedau tywyll?';
