<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author soer9648 <soer9648@eucl.dk>
 */
$lang['picker']                = 'Wrap Plugin';
$lang['column']                = 'række';
$lang['box']                   = 'simpel centreret boks';
$lang['info']                  = 'info boks';
$lang['tip']                   = 'tip boks';
$lang['important']             = 'vigtig boks';
$lang['alert']                 = 'alarm boks';
$lang['help']                  = 'hjælp boks';
$lang['download']              = 'download boks';
$lang['todo']                  = 'todo boks';
$lang['clear']                 = 'ryd flydere';
$lang['em']                    = 'specielt fremhævet';
$lang['hi']                    = 'fremhævet';
$lang['lo']                    = 'mindre vigtigt';
