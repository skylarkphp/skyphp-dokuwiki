<?php

$lang['picker']    = 'Wrap Plugin';

$lang['column']    = 'columns';
$lang['box']       = 'simple centered box';
$lang['info']      = 'info box';
$lang['tip']       = 'tip box';
$lang['important'] = 'important box';
$lang['alert']     = 'alert box';
$lang['help']      = 'help box';
$lang['download']  = 'download box';
$lang['todo']      = 'todo box';

$lang['clear']     = 'clear floats';

$lang['em']        = 'especially emphasised';
$lang['hi']        = 'highlighted';
$lang['lo']        = 'less significant';
