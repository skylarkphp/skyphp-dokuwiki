<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Robert Bogenschneider <bogi@uea.org>
 */
$lang['picker']                = 'Wrap-kromaĵo';
$lang['column']                = 'kolumnoj';
$lang['box']                   = 'simpla centrita skatolo';
$lang['info']                  = 'inform-skatolo';
$lang['tip']                   = 'konsil-skatolo';
$lang['important']             = 'grava skatolo';
$lang['alert']                 = 'avert-skatolo';
$lang['help']                  = 'help-skatolo';
$lang['download']              = 'elŝut-skatolo';
$lang['todo']                  = 'farendaĵ-skatolo';
$lang['clear']                 = 'liberigi la randojn';
$lang['em']                    = 'aparte emfazita';
$lang['hi']                    = 'markita';
$lang['lo']                    = 'malpli grava';
