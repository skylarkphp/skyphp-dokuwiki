<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Domingo Redal <docxml@gmail.com>
 */
$lang['picker']                = 'Wrap Plugin';
$lang['column']                = 'columnas';
$lang['box']                   = 'caja simple centrada';
$lang['info']                  = 'caja de información';
$lang['tip']                   = 'caja de consejo';
$lang['important']             = 'caja importante';
$lang['alert']                 = 'caja de alerta';
$lang['help']                  = 'caja de ayuda';
$lang['download']              = 'caja de descarga';
$lang['todo']                  = 'caja de TODO';
$lang['clear']                 = 'limpiar float';
$lang['em']                    = 'especialmente enfatizado';
$lang['hi']                    = 'destacado';
$lang['lo']                    = 'menos significativo';
