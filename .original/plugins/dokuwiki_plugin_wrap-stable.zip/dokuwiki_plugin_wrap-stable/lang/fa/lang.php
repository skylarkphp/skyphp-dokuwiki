<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author reza_khn <reza_khn@yahoo.com>
 * @author Sam01 <m.sajad079@gmail.com>
 */
$lang['picker']                = 'افزونه قراردادن';
$lang['column']                = 'ستون‌ها';
$lang['box']                   = 'جعبه محور ساده';
$lang['info']                  = 'جعبه اطلاعات';
$lang['tip']                   = 'جعبه نکته';
$lang['important']             = 'جعبه مهم';
$lang['alert']                 = 'جعبه هشدار';
$lang['help']                  = 'جعبه کمک';
$lang['download']              = 'جعبه دانلود';
$lang['todo']                  = 'جعبه کاربردی';
$lang['clear']                 = 'جعبه شناور';
$lang['em']                    = 'تاکید مهم';
$lang['hi']                    = 'برجسته';
$lang['lo']                    = 'کم اهمیت';
