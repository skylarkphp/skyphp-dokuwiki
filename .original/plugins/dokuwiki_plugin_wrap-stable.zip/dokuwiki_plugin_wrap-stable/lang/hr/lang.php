<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Davor Turkalj <turki.bsc@gmail.com>
 */
$lang['picker']                = 'Wrap dodatak';
$lang['column']                = 'kolone';
$lang['box']                   = 'običan centrirani okvir';
$lang['info']                  = 'info okvir';
$lang['tip']                   = 'okvir savjet';
$lang['important']             = 'okvir važno';
$lang['alert']                 = 'okvir upozorenja';
$lang['help']                  = 'okvir pomoći';
$lang['download']              = 'okvir učitavanja';
$lang['todo']                  = 'okvir preostalo';
$lang['clear']                 = 'prazan okvir';
$lang['em']                    = 'posebno naglašeni';
$lang['hi']                    = 'istaknuti';
$lang['lo']                    = 'manje bitan';
