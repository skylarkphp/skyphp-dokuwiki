<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Marina Vladi <deldadam@gmail.com>
 */
$lang['picker']                = 'Wrap-csatoló';
$lang['column']                = 'oszlopok';
$lang['box']                   = 'egyszerű, középre igazított doboz';
$lang['info']                  = 'információs doboz';
$lang['tip']                   = 'tippdoboz';
$lang['important']             = 'fontos doboz';
$lang['alert']                 = 'figyelmeztető doboz';
$lang['help']                  = 'súgódoboz';
$lang['download']              = 'letöltéshez doboz';
$lang['todo']                  = 'teendőhöz doboz';
$lang['clear']                 = 'float tiltása';
$lang['em']                    = 'különösen hangsúlyos';
$lang['hi']                    = 'kiemelt';
$lang['lo']                    = 'kevésbé fontos';
