<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Edmondo <snarchio@gmail.com>
 * @author Giovanni <Giovanni.Garofalo@outlook.com>
 * @author Torpedo <dgtorpedo@gmail.com>
 */
$lang['picker']                = 'Plugin Wrap';
$lang['column']                = 'colonne';
$lang['box']                   = 'box semplice centrato';
$lang['info']                  = 'box informazione';
$lang['tip']                   = 'box suggerimento';
$lang['important']             = 'box importante';
$lang['alert']                 = 'box attenzione';
$lang['help']                  = 'box aiuto';
$lang['download']              = 'box download';
$lang['todo']                  = 'box cose da fare';
$lang['clear']                 = 'elimina elementi flottanti';
$lang['em']                    = 'enfatizzato speciale';
$lang['hi']                    = 'evidenziato';
$lang['lo']                    = 'meno importante';
