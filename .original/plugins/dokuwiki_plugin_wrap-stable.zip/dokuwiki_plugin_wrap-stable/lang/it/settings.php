<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Edmondo <snarchio@gmail.com>
 * @author Torpedo <dgtorpedo@gmail.com>
 */
$lang['noPrefix']              = 'quali nomi di classi (elenco separato da virgole) non devono avere il prefisso "wrap_"?';
$lang['restrictedClasses']     = 'restringi l\'uso del plugin a queste classi (elenco separato da virgole)';
$lang['restrictionType']       = 'tipo di restrizione, specifica se le classi sopra devono essere incluse o escluse';
$lang['restrictionType_o_0']   = 'permetti tutte le classi tranne quelle sopra';
$lang['restrictionType_o_1']   = 'restringi solo alle classi sopra e a nessun\'altra';
$lang['syntaxDiv']             = 'Quale sintassi usare nella paletta degli strumenti per riquadri a blocchi?';
$lang['syntaxSpan']            = 'Quale sintassi usare nella paletta degli strumenti per riquadri in linea?';
$lang['darkTpl']               = 'Ottimizzare i colori per tema scuro?';
