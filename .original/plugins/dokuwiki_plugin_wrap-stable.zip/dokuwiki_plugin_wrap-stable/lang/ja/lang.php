<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Satoshi Sahara <sahara.satoshi@gmail.com>
 */
$lang['picker']                = 'Wrap プラグイン';
$lang['column']                = '多段組み';
$lang['box']                   = '中央配置枠';
$lang['info']                  = '情報枠';
$lang['tip']                   = 'ヒント枠';
$lang['important']             = '重要枠';
$lang['alert']                 = '警告枠';
$lang['help']                  = 'ヘルプ枠';
$lang['download']              = 'ダウンロード枠';
$lang['todo']                  = 'TODO枠';
$lang['clear']                 = '回り込み解除';
$lang['em']                    = '特に強調';
$lang['hi']                    = 'ハイライト表示';
$lang['lo']                    = '非強調（薄色表示）';
