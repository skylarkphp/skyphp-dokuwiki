<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Myeongjin <aranet100@gmail.com>
 */
$lang['picker']                = 'Wrap 플러그인';
$lang['column']                = '단';
$lang['box']                   = '간단한 가운데 상자';
$lang['info']                  = '정보 상자';
$lang['tip']                   = '팁 상자';
$lang['important']             = '중요 상자';
$lang['alert']                 = '경고 상자';
$lang['help']                  = '도움말 상자';
$lang['download']              = '다운로드 상자';
$lang['todo']                  = '할 일 상자';
$lang['clear']                 = '플로트 지우기';
$lang['em']                    = '특히 강조';
$lang['hi']                    = '강조';
$lang['lo']                    = '덜 중요함';
