<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Gerrit Uitslag <klapinklapin@gmail.com>
 */
$lang['picker']                = 'Wrap Plugin';
$lang['column']                = 'kolommen';
$lang['box']                   = 'simpele gecentreerde blok';
$lang['info']                  = 'informatie blok';
$lang['tip']                   = 'tip blok';
$lang['important']             = 'belangrijk blok';
$lang['alert']                 = 'waarschuwingsblok';
$lang['help']                  = 'helpblok';
$lang['download']              = 'downloadblok';
$lang['todo']                  = 'tedoen blok';
$lang['clear']                 = 'reset drijvende blokken (clear floats)';
$lang['em']                    = 'bijzonder benadrukken';
$lang['hi']                    = 'gemarkeerd';
$lang['lo']                    = 'minder belangrijk';
