<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Aurora Voje <aurora.voje@jbv.no>
 */
$lang['picker']                = 'Omhylningsplugin
Omkransningsplugin';
$lang['column']                = 'kolonner';
$lang['box']                   = 'enkel sentrert boks';
$lang['info']                  = 'infoboks';
$lang['tip']                   = 'tipsboks';
$lang['important']             = 'viktig boks';
$lang['alert']                 = 'alarmboks';
$lang['help']                  = 'hjelpeboks';
$lang['download']              = 'nedlastningsboks';
$lang['todo']                  = 'gjøremålsboks';
$lang['clear']                 = 'tøm floats';
$lang['em']                    = 'spesielt fremhevet (singular)
spesielt fremhevede (plural)';
$lang['hi']                    = 'markert (singular)
markerte (plural)';
$lang['lo']                    = 'mindre viktig';
