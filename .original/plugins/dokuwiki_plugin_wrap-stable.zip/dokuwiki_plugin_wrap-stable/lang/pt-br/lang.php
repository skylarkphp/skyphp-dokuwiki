<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Sérgio Motta <sergio@cisne.com.br>
 * @author Fábio Nogueira <fnogueira@gnome.org>
 */
$lang['picker']                = 'Plugin Wrap';
$lang['column']                = 'colunas';
$lang['box']                   = 'caixa centralizada simples';
$lang['info']                  = 'caixa de informação';
$lang['tip']                   = 'caixa de sugestão';
$lang['important']             = 'caixa importante';
$lang['alert']                 = 'caixa de alerta';
$lang['help']                  = 'caixa de ajuda';
$lang['download']              = 'caixa de download';
$lang['todo']                  = 'caixa de tarefas a fazer';
$lang['clear']                 = 'limpar';
$lang['em']                    = 'especialmente enfatizado';
$lang['hi']                    = 'enfatizado';
$lang['lo']                    = 'menos significativo';
