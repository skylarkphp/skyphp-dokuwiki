<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Martin Michalek <michalek.dev@gmail.com>
 */
$lang['picker']                = 'Wrap Plugin';
$lang['column']                = 'stĺpec';
$lang['em']                    = 'zvlášť zdôraznený';
$lang['hi']                    = 'zvýraznený';
$lang['lo']                    = 'menej významný';
