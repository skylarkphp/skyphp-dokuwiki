<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Марко М. Костић <marko.m.kostic@gmail.com>
 */
$lang['picker']                = 'Прикључак за преламање';
$lang['column']                = 'колоне';
$lang['box']                   = 'једноставна кутија на средини';
$lang['info']                  = 'инфо кутија';
$lang['tip']                   = 'кутија са саветима';
$lang['important']             = 'важна кутија';
$lang['alert']                 = 'кутија са узбуном';
$lang['help']                  = 'кутија за испомоћ';
$lang['download']              = 'кутија за преузимање';
$lang['todo']                  = 'кутија са задацима';
$lang['clear']                 = 'очисти плутајуће';
$lang['em']                    = 'нарочито назначено';
$lang['hi']                    = 'означено';
$lang['lo']                    = 'мање важно';
