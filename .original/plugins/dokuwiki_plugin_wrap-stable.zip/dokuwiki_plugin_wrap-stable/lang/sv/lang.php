<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Tor Härnqvist <tor@harnqvist.se>
 */
$lang['picker']                = 'Wrap-plugin';
$lang['column']                = 'kolumner';
$lang['info']                  = 'infolåda';
$lang['tip']                   = 'tipslåda';
$lang['important']             = 'viktigt-box';
$lang['help']                  = 'hjälp-box';
$lang['download']              = 'nedladdningsbox';
$lang['todo']                  = 'att böra-box';
$lang['hi']                    = 'förstärkt';
$lang['lo']                    = 'mindre betydelsefullt';
