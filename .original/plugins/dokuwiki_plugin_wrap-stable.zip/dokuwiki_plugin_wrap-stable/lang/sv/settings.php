<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Tor Härnqvist <tor@harnqvist.se>
 */
$lang['noPrefix']              = 'Vilka (komma-separerade) class-namn ska undantas från att få prefix "wrap_"?';
$lang['restrictedClasses']     = 'begränsa plugin-användningen till dessa (komma-separerade) class ';
$lang['darkTpl']               = 'Optimera färger för mörkt templat?';
