<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author lainme <lainme993@gmail.com>
 * @author maie <dokuwiki@maie.name>
 */
$lang['noPrefix']              = '哪些CSS类不需要加上“wrap_"前缀？(逗号分隔)';
$lang['restrictedClasses']     = '将插件的使用限制应用到这些类(逗号分隔)';
$lang['restrictionType']       = '限制类型，指定上述类应该被包含或排除';
$lang['restrictionType_o_0']   = '允许除上述类之外的所有类';
$lang['restrictionType_o_1']   = '仅允许上述类';
$lang['syntaxDiv']             = '在编辑工具栏的选择器中应对块级元素使用何种语法？';
$lang['syntaxSpan']            = '在编辑工具栏的选择器中应对行内元素使用何种语法？';
$lang['darkTpl']               = '优化黑模板的颜色？';
